import hashlib,json,sys,zipfile
with zipfile.ZipFile(sys.argv[1]) as z:
 m=json.loads(z.read("portable-manifest.json"))
 assert len(z.namelist())==len(set(z.namelist())),"Duplicate ZIP entries"
 assert set(z.namelist())==set(m["files"])|{"portable-manifest.json"},"Inventory mismatch"
 for name,expected in m["files"].items():
  data=z.read(name)
  assert len(data)==expected["bytes"] and hashlib.sha256(data).hexdigest()==expected["sha256"],name
 assert z.testzip() is None,"CRC failure"
 print("PASS: portable inventory, SHA-256 and CRC",len(m["files"]),"files; exclusions:",m["excluded"])
