# Change Log

## v1.0.13 — Shader / Resource / GPU-driven Scale（2026-11-01）

- 基于已合v1.0.12 skill d049afe / tests 9278d9b，五轴同版：Shader artifact/ABI/hot reload；pipeline/cache/build；streaming/budget；GPU-driven；LOD/Hi-Z/particles/multi-view。
- 修正命中卡片的虚构dispatch-indirect stage、dispatch乘积limit、Count必要论、byte-count扩展归属、VMA缓存维护和立即退休等冲突。
- 原文件锚点扩充，运行时净增0、白名单≤200；八模块、原启动/触发、MIT、安全打包与G1–G6保留。
- 原40行为题冻结，新24 ENG13成对条件输入单列；原12题token基线不改。原创C++/GLSL Engine Scale Lab在tests仓，编译/软件Vulkan/移动真机/Live证据分层，不由静态测试推断性能。
- 候选版本，不自动发布/合main；精确计划hash、来源、失败原始记录及真实完成边界见配对Draft PR和tests报告。

## v1.0.12 — Android System Rendering（2026-11-01）

- 基于已合v1.0.11 skill1f85b8b/tests3a8ea8b，只扩C1多实例Surface、C2媒体AHB帧合同、C3颜色/HDR/透明输出。
- 修正生命周期命中范围的wait-idle伪超时、统一idle与present退休混淆、AHB当窗口等旧冲突；owner/ack/generation与shared-device故障分层。
- 原文件按锚点扩充，运行时知识净增0、包预算200；原启动/触发/MIT/G1–G6保留。
- 新SYS12题与原28题分cohort；Media Surface Lab隔离fixture不冒充Java/Native/GPU设备执行，Live/宿主/Device继续明确未验证。
- 精确计划、来源矩阵、测试/包证据在配对tests仓，未自动发布或合main。

## v1.0.11 — Mobile Vulkan Evolution（2026-11-01）

- 基于已合入的v1.0.10主仓349dc35b与tests75630ee5扩展移动端能力，不回退其安全打包、按段读取和历史隔离。
- C1/C2：移动采集/持续性能与fault地址-资源代际取证，修正无证据根因排除。
- C3/C4：tile-aware API卡、外部资源API卡与Vulkan/OpenCL往返工作流；支持/启用/owner/同步/失败回退分别说明。
- C5：可选神经图形工作流与固定版本框架集成案例，区分native、仿真与传统fallback。
- 保留八模块、最小启动、触发条件和G1–G6；最多4新知识文件，实际包预算200，来源与评估证据置tests仓。
- 新12移动题单列，旧16场景保留；Live/Device/宿主及provider token未执行时保持BLOCKED或未验证，不声称全能力验收。


## 未发布修订（2026-10-24 至 2026-10-25）

- 修正 API 版本数值宏、1.2 / 1.3 / 1.4 feature 必须支持起点与字段归属，以及 1.4 核心化扩展、limits、scalar layout 和 maintenance5/6 边界；为关键规则补充官方链接。
- 修正 frame fence reset 时机与 acquire / submit 失败路径，present wait semaphore 改按 swapchain image 管理；区分提交完成和 presentation 资源退役，同步关联模型、API 卡片与 workflow。
- Verification Gate 按纯知识问答、设计审查和实际实现结论选择范围，修正 Validation clean 的证据强度；补充四个定向行为评估场景，不将其视为已执行结果。
- 保持发布版本不变；未执行真实 Vulkan / GPU / Android 运行验收。
- 静态验证：skill-creator `quick_validate.py` 通过；新增无依赖 `scripts/check-skill.mjs`，检查 Git 可见文件的 UTF-8、Markdown 围栏、本地文件链接、入口路径和模块计数。检查发现的两份 API 模板嵌套围栏已改用外层四反引号。
- 四项定向行为评估已在隔离上下文执行并通过，原始回答、加载文件与证据边界见 `../07_integration_pack/behavior_evaluation.md`；不代表完整历史题库、模型稳定性或 GPU 运行验收通过。
- 提交交付时同步远端 v1.0.9，保留精简入口、项目诊断与规范修订，合并本轮适用验证范围与同步修复。历史四项行为证据不覆盖合并后输入；合并后结构检查单独记录，源文件 202 超出旧 200 文件预算，不宣称发布就绪。

## v1.0.9 — 规范对齐与轻量化（2026-10-17）

- 七文件强制预读改为 hard_rules 全文 + task_routing_rules 的 routing-entry 与命中段落；八模块、触发词和宿主配置保留。
- SKILL 症状直达表移到 task_routing_rules，分类器与检索策略不再维护平行分发表。
- 输出模板、准确性、检索循环与验证关卡增加稳定锚点，入口 README 内记录旧规则迁移表；入口重构本身不新增文件。
- 19 条硬规则原文不变，Evidence Map + Architecture Map、修改影响面、R1-R5、G1-G6 与第三方版本约束仍保留。
- 静态缩减不等于 live 验证；实际 token 降低 30% 为待测目标，不宣称已达标。

### 技术资料同步范围

- 按 Vulkan 1.4.365 registry / validusage 核对 API 卡符号、限定成员和 VUID；纠正已确认的虚构符号、失效编号及语义错配。机械匹配不等于所有规范语义已经验证，复现脚本与审计证据保存在独立测试仓库。

- Descriptor Buffer 文档校正：opaque descriptor 生成、真实 flags、layout 查询、复制与读取可见性。
- Descriptor Heap 补充能力边界、实际 descriptor 大小与 stride，并新增对应 API 卡片。
- YCbCr / AHardwareBuffer 补充 descriptor count 与相关使用边界。
- 能力查询区分 SDK / headers、运行时 ICD 和 feature；工具、Apple 与 Blender 路线按目标能力和工程约束决策。
- 上述为文档更新范围，不代表已进行 GPU 运行验证或真实模型行为验收；具体执行结果须以对应测试记录为准。

## v0.1

- 建立专家行为控制模块。
- 拆分 role、hard rules、task classifier、response formats、debug priority、performance priority、accuracy check。
- 控制根目录 `../../SKILL.md` 只作为入口，不承载大段知识。
- 引入准确性分级：12 标签体系（详见 `01_source_map_and_api_manual_strategy/source_tags.md`）。

## v0.1 决策（已解决）

- 默认使用 Vulkan 1.3+，但保留 1.0/1.1/1.2 兼容说明。[GUIDE][ENGINE]
- 新项目默认推荐 Dynamic Rendering，复杂多 subpass 场景保留 RenderPass。[GUIDE][ENGINE]
- Android 默认以 SurfaceView + ANativeWindow 为主，其他方案（如 TextureView）需说明限制。[ANDROID]
- 不强制要求 RenderDoc / AGI，但 Debug 结论必须提供可验证路径；有工具时应优先使用。[TOOL][ENGINE]
- 增加“禁止只输出概念解释”规则，已写入 `hard_rules.md`。[ENGINE]
- 项目级文件修改模板暂缓到 v0.2，当前通过 `hard_rules.md` 第 6 条覆盖核心修改要求。

## 待调整

- v0.2 是否加入项目级文件修改模板。（已解决：当前通过 `hard_rules.md` 第 6 条覆盖核心修改要求，v0.2 不再单独加入模板。）

## v1.0.1

### Vulkan 1.4 知识库补充

- 补充核心化扩展、强制功能、最低限制提升。[GUIDE][SPEC]
- 新增 15 张卡片（vulkan_1_4_overview、timeline_semaphore、descriptor_indexing 等）。
- 增量补充 5 张已有卡片（dynamic_rendering、synchronization2 等）。
- 版本基线从 Vulkan 1.3+ 升级为 Vulkan 1.3+/1.4。

### 新增硬规则（hard_rules.md #12-#15）

- **#12 Vertex Attribute 布局校验**：核对 format / offset / stride 与实际数据布局；原有等宽要求及错误 VUID 引用已在 v1.0.6 审查修订中纠正。[SPEC][ENGINE]
- **#13 相机参数基于模型 bbox**：`target/distance/farP` 必须基于 AABB 计算，禁止硬编码。[ENGINE]
- **#14 PBR 光源按尺度缩放**：`1/d²` 衰减下 `intensity = targetRadiance × distance²`。[ENGINE][HEUR]
- **#15 Vulkan 销毁幂等**：handle 置空 + `vkDeviceWaitIdle` 可重复 + `vkDestroy*` 容忍 NULL_HANDLE。[SPEC]

### 第三方库 API 准确性规则（accuracy_check.md）

- 新增 "Third-Party Library API Accuracy" 小节，6 条规则：标注版本号、6 个月回查、不编造签名、Vulkan backend 双重标注、API 变更点显式列出、检索优先最新 release notes。

### 任务路由与检索策略

- `../07_integration_pack/task_routing_rules.md` 新增第 10 类任务"第三方库集成类"。
- `../07_integration_pack/retrieval_policy.md` 新增 §5 第三方库 API 检索规则。

### 资源生命周期与幂等销毁设计

- `../05_workflows/05_resource_management/manage_resource_lifetime.md` 新增"幂等销毁设计"与"常见多次调用场景"小节（含 SafeDestroy wrapper + 5 类组合调用：main+析构、异常+正常、窗口关闭+析构、swapchain recreate+shutdown、device lost+析构）。
- `../02_core_mental_model/resource_lifecycle.md` 新增"幂等销毁"心智模型小节。

### 行尾规范化

- `../05_workflows/workflow_index.md`、`../07_integration_pack/retrieval_policy.md` 由 CRLF 转 LF。

## v1.0.3

### 文件数量精简（248 → 196，满足 ClawHub ≤200 限制）

为满足 ClawHub 提交的 200 文件上限，分三阶段精简文件数量，总计减少 52 个文件。所有合并文件保留原内容，仅做层级调整以保持向量检索命中率。

#### Phase 1：排除测试输入数据（248 → 236，-12）

- `.gitignore` 新增 `tests/prompts/*.txt` 规则，TC9 提示词 fixture 本地保留但不跟踪。

#### Phase 2a：合并 `06_cases/`（236 → 214，-22）

- 7 个子目录各合并为 1 个文件，33 → 11 文件。
- 合并文件 H1 使用 `# Cases: <Category>`，原 case 降级为 `## Case: <原 case 名>` 锚点，原 `##` 段落降级为 `###`。
- 涉及文件：`01_black_screen`、`02_descriptor_pipeline`、`03_sync_layout`、`04_swapchain_android`、`05_compute`、`06_performance`、`07_engine_architecture`。
- 同步更新 `06_cases/case_index.md`、`06_cases/README.md`、`MODULE_SUMMARY.md`（33→11）和 3 个交叉引用文件。

#### Phase 2b：合并 `04_debug_playbooks/`（214 → 196，-6）

- 6 组合并，28 → 22 文件。
- 合并文件以 `## Debug Playbook: <原 playbook 名>` 作为锚点，原 `##` 段落降级为 `###`。
- 涉及合并组：
  - `03_validation_errors/`：`descriptor_binding_error` + `pipeline_layout_error` → `04_debug_playbooks/03_validation_errors/descriptor_pipeline_layout_errors.md`；`image_layout_error` + `synchronization_hazard` → `04_debug_playbooks/03_validation_errors/layout_sync_hazard_errors.md`。
  - `06_performance_symptoms/`：`bandwidth_high` + `fullscreen_pass_cost` → `04_debug_playbooks/06_performance_symptoms/bandwidth_fullscreen_cost.md`；`barrier_overuse` + `draw_call_bottleneck` → `04_debug_playbooks/06_performance_symptoms/barrier_draw_call_stall.md`；`cpu_frame_time_high` + `descriptor_update_overhead` → `04_debug_playbooks/06_performance_symptoms/cpu_overhead_symptoms.md`；`pipeline_creation_stutter` + `startup_time_high` → `04_debug_playbooks/06_performance_symptoms/pipeline_startup_stutter.md`。
- `tests/test_templates.py` 增加 `## Debug Playbook:` 前缀检测，合并文件使用 `###` 段落校验。
- 同步更新 `04_debug_playbooks/README.md`、`04_debug_playbooks/debug_priority_index.md`、`MODULE_SUMMARY.md`（28→22）和 52 个交叉引用文件。

### 行尾规范化（Phase 2b 副产物）

- `_fix_pb_refs.py` 批量替换留下的 CRLF 行尾统一为 LF，涉及 43 个文件。
- `git diff --check` 全部干净。

## v1.0.8 — Project Diagnosis

### 真实仓库诊断与源码证据

- 新增 `05_workflows/01_renderer_setup/project_diagnosis.md`：把陌生 Vulkan / 图形引擎仓库分析固化为 Project Reconnaissance → Evidence Map → Architecture Map → Change Impact → Implementation Handoff → Verification Gate。
- 新增 `[CODE]` 来源标签：用于“当前目标项目源码直接证据”；只证明项目事实，不能覆盖 `[SPEC]` / `[REGISTRY]` / `[REF]`，项目实现与规范冲突时必须报告实现风险。
- `accuracy_check.md` 与 `hard_rules.md` 增加源码证据约束：禁止只根据文件名 / 类名猜项目架构；未读取实现的关键判断标记“未验证”。

### 源码级修改影响面

- `../02_core_mental_model/regression_reasoning.md` 增加源码级影响面映射：抽象 Vulkan 对象依赖必须落到文件 / 类 / 函数。
- 修改项统一分为 Must Change / Should Change / Can Defer / Do Not Change，分别控制必要修改、技术债、可延后项和明确不动项。
- 版本升级不再自动等价于迁移 Dynamic Rendering / Sync2 等现代路径；必须结合现有源码依赖、目标收益和回归面单独决策。

### 行为测试修订：Architecture Map 强制出口

- v1.0.8 模型行为测试发现：版本升级评估与 Android crash 场景可能给出 `[CODE]` Evidence Map，却跳过 Architecture Map。
- `hard_rules.md` 新增规则 #19：真实项目任务无论偏升级 / Debug / 性能 / 实现，都必须先输出 Evidence Map + Architecture Map，再进入根因、Change Impact 或实施计划。
- `../05_workflows/01_renderer_setup/project_diagnosis.md` Step 2 同步改为 Evidence Map + Architecture Map；允许只画与当前任务相关的子图，但未知层必须显式标记“未验证”。

### 路由与交付协议

- `../../SKILL.md`、task classifier、response formats、progressive retrieval、task routing、retrieval policy 接入“项目诊断类”。
- 项目诊断输出要求包含 `[CODE]` Evidence Map、Architecture Map、Files To Modify、Dependency Order、Risks、Rollback、DoD。
- 真实项目实现任务优先复用项目现有 Resource / Descriptor / Pipeline / Command / Queue 架构，除非源码证据证明现有抽象本身是问题根因。

### 文件数量

- 新增 1 个 workflow 文件：`05_workflows` 45 → 46。
- 预计 Git 跟踪文件 198 → 199，继续满足 ClawHub ≤200 文件限制。

## v1.0.7 — Onboarding

针对 SkillHub 评测（T 4.8 / R 4.5 / A 4.4 / C 4.8 / E 4.8）的上手体验优化，不改动知识主体（API 卡片 / playbook / workflow / case 内容不变），无新增文件（保持 198/200）。

- **适用性（A）**：README ×2 新增"安装与调用"章节（Claude Code / TraeCode / 其他 Agent Skills 宿主的放置路径与降级模式）与 8 条可复制提问示例（每条标注触发模块）；`../../SKILL.md` description 补充触发场景句式，提高宿主自动命中率。
- **可靠性（R）**：`progressive_retrieval.md` R2 新增分任务类型最小提问模板（9 类任务 × 标准三项信息），信息收集从临时发挥变为固定协议；用户提供齐全时跳过 R2 直接路由。
- **规范性（C）**：README 新增"上手路径"（直接提问 / 知识地图 / 深入学习三条路线）。
- **有效性（E）**：`../../SKILL.md` 任务路由段新增"症状 / 意图 → 直达速查表"（20 行症状直达 playbook / workflow / case / 决策框架），免读索引直接加载。
- **可信任度（T）**：`01_source_map_and_api_manual_strategy/trusted_sources.md` 新增中文辅助阅读资源节，显式标注非官方、冲突以英文官方 Spec 为准、引用等级不高于 [HEUR]。

## v1.0.6 — Rendering Engine Architect

### 审查修订（2026-09-12）

- `metadata.keywords` 改为字符串，符合 Agent Skills 的 metadata 类型约束。
- 顶点属性规则按实际布局校验，补充 padding 反例与可追溯的格式支持、portability subset VUID。
- 架构模型与 Fence/Semaphore API 卡统一使用 timeline 类型的 `VkSemaphore`，补充 feature 与创建链。
- Dynamic Rendering 决策补充 local read 扩展路径、Vulkan 1.4 附件支持边界与官方来源。
- 澄清流程先检查已有证据，仅对影响路由或结论的剩余缺口提问；入口与输出模板同步，日志条件限定故障诊断。

### 架构能力与文件整理

- 新增引擎架构心智模型：RHI / Frame Context / Resource Manager / Render Graph / Descriptor Model / Pipeline Manager / Queue Model 七子系统与影响链。
- 新增架构决策框架：D1-D7 七组 trade-off，六要素结构（适用/不适用/收益/复杂度/性能风险/重新评估条件），不默认新技术。
- 六个关键 workflow 增加架构决策阶段（需求→约束→Candidate→Trade-off→Decision），Verification Gate 与 Progressive Retrieval 不变。
- 新增四个架构迁移决策案例：bindless 迁移判断、RenderGraph 引入拐点、资源生命周期拆分、async compute 反噬。
- 入口与路由接线：SKILL.md、task_classifier、task_routing_rules、README×2。
- MODULE_SUMMARY（02_core_mental_model 15→16）。文件数 199→200（达 ClawHub 上限）。
- 修正存量内容的 3 个编造 VUID 编号（`VUID-VkDescriptorSetAllocateInfo-pSetLayouts-03044` / `VUID-vkUpdateDescriptorSets-None-03047` / `VUID-VkImageMemoryBarrier-oldLayout-01197`，波及 4 文件 8 处，均经官方规范验证）与 acquire/present semaphore 必须为 binary 的歧义表述。
- 文件数量优化：`07_integration_pack` 的 maintenance_plan / release_checklist / token_budget_policy（三者均为零引用孤儿文件）合并为 `07_integration_pack/maintenance_release_token_policy.md`，git 跟踪文件 200 → 198，恢复 ClawHub ≤200 限额余量。

## v1.0.5

### Intelligent Retrieval：检索循环 + 证据驱动决策树 + 领域补白

新增 `00_expert_entry/progressive_retrieval.md`：五阶段检索循环（R1 查询分解 / R2 意图澄清 / R3 首轮路由 / R4 证据评估 / R5 二轮定向检索）；复杂跨类任务先分解再路由，模糊提问先给 ≤3 项最小提问清单，低置信子问题强制二轮补载；循环输出作为 Verification Gate 输入。

Debug Playbook §3 全量决策表化（18 个 playbook 文件 / 24 个小节）：快速验证路径从线性步骤改为"检查（成本升序）→ 结果分支 → 剪枝（引用 §2 假设编号）"的证据驱动决策表；模板与 README 同步新规范。

新增 API 卡片：`03_api_manual/06_pipeline/mesh_shader.md`（VK_EXT_mesh_shader、meshlet、GPU-driven，Android 支持边界显式标注）与 `03_api_manual/02_surface_swapchain/desktop_windowing.md`（SDL/GLFW/Win32、最小化/resize/DPI 与 swapchain 生命周期）。

入口与路由接入：`../../SKILL.md` 启动加载第 7 项与回答规则；`00_expert_entry/task_classifier.md` 跨类型先分解；`07_integration_pack/retrieval_policy.md` §2 降级为首轮路由；`00_expert_entry/response_formats.md` 新增 §0.5 意图澄清格式；`00_expert_entry/verification_gate.md` 交叉引用。索引同步：api_index、MODULE_SUMMARY（00_expert_entry 10→11、03_api_manual 66→68）。

## v1.0.4

### Production Expert：可靠性、根因判断、回归验证

不扩展新的 Vulkan API 大类，不新增顶层知识模块（仅新增 3 个文件、无删除，git 跟踪文件 192 → 195，仍满足 ClawHub ≤200 限制）。本版本聚焦真实工程任务的可靠性：结论出口统一过验证关卡，修改前先推影响面，修复结论区分分级，修复后按清单回归。

#### 新增统一验证关卡（Verification Gate，G1-G6）

- 新增 `00_expert_entry/verification_gate.md`：任何"完成 / 解决 / 根因已修 / 性能已优化"类结论，出口前依次过 G1 API 合法性 → G2 生命周期 → G3 同步 → G4 Validation Layer → G5 RenderDoc / AGI → G6 平台回归；每关标注已验证 / 未验证 / 不适用，不可验证的关卡默认不通过。
- G4 明确 Validation clean 只是必要条件而非成功标准；G6 覆盖 Android rotation / pause / resume / Surface-Swapchain recreate。

#### 新增修改影响面推理（`02_core_mental_model/regression_reasoning.md`）

- 依赖传播规则：DescriptorSetLayout → PipelineLayout → Pipeline → DescriptorSet 重分配与重绑定；Image → ImageView → RenderTarget / Framebuffer；Swapchain 尺寸 → depth / offscreen / RenderArea / viewport / 特殊分辨率特效；Frames-in-flight → per-frame 资源隔离与生命周期；Barrier → producer / consumer / stage / access / layout / queue ownership。
- 修改前先推影响面，影响类别决定回归验证范围。

#### 新增回归验证清单（`07_integration_pack/regression_checklist.md`）

- 六类回归：correctness / rendering / resource lifecycle / synchronization / Android lifecycle / performance。
- 供 Verification Gate G6 与 Debug Playbook §7 选用。

#### Debug Playbook 统一推理链与修复分级（22 文件全量审查）

- 统一推理链写入模板与 README：Symptom → Hypothesis → Evidence → Root Cause → Workaround → Minimal Fix → Structural Fix → Regression Verification；禁止把"现象消失"等同于"找到根因"。
- 修复分级全量更名并统一语义：最小修复 → Workaround（临时绕过）、稳定修复 → Minimal Fix（根因最小修复）、工程化修复 → Structural Fix（结构性 / 防复发）；涉及 `04_debug_playbooks/debug_playbook_template.md`、README 及全部带修复分级的 playbook。
- `06_cases/case_template.md` 与全部 7 个 case 文件（29 个案例）同步修复分级：case 侧旧"最小修复"内容为根因修复，语义映射为 Minimal Fix；旧"稳定修复 / 工程化修复"合并为 Structural Fix；`06_cases/01_black_screen/case_black_screen.md` 的临时 cullMode 条目单独提取为 Workaround 小节。
- `00_expert_entry/debug_priority.md`、`04_debug_playbooks/debug_priority_index.md`、`01_source_map_and_api_manual_strategy/api_card_template.md` 的"给出最小修复"步骤统一改为"给出 Workaround / Minimal Fix / Structural Fix"。
- 06_cases 模块行尾规范化：7 个 case 文件与 `06_cases/case_tags.md` CRLF → LF，并清除历史行尾空白；至此 references 下全部 Markdown 文件为 LF 行尾，`git diff --check` 干净。

#### 入口规则与路由更新

- `../../SKILL.md`：版本 1.0.4；启动加载顺序增加第 6 项 `verification_gate.md`；回答规则第 6 条"Verification Gate 状态（G1-G6 逐关标注）"；禁止行为新增"现象消失 ≠ 根因修复"与"Validation clean 不是唯一成功标准"。
- `hard_rules.md` 新增 #16（修复必须区分三级，Workaround 后须继续定位根因或显式标注残留风险）与 #17（Validation clean 非唯一成功标准，结论前过 G1-G6）。
- `response_formats.md` 新增 §0"统一出口段：Verification Gate"，故障调试类输出结构增加修复分级与 Verification Gate 状态。
- `../07_integration_pack/task_routing_rules.md` 新增第 11 类任务"统一出口：Verification Gate"，适用于设计 / 实现 / Debug / 优化等一切输出结论性判断的任务。

#### 索引同步

- `MODULE_SUMMARY.md`：00_expert_entry 9 → 10、02_core_mental_model 14 → 15、07_integration_pack 8 → 9。
- `00_expert_entry/README.md`、`02_core_mental_model/README.md` 文件列表同步。

## v1.0.14（2026-11-07）：Mobile Hybrid Lighting & Temporal Quality

新增基础光照/阴影/反射回退、独立 query-only 能力、AS 生命周期/同步、alpha/OMM 条件边界、时域语义/失效/非神经滤波与画质预算分档。修正 modern_patterns 的 timeline WSI 示例、过宽版本保证、add_depth_pass 的普通 depth present 与阶段/layout 说明，以及 compute 卡片命中的 subpass 旧说法。

八模块、197个知识文件、200文件白名单、硬规则、启动/宿主配置保持；新权威锚点按需读取。配对 tests 保留旧64并新增20个VIS14题及精简实验。文档/静态/编译/软件Vulkan与真实模型/宿主/Android/OMM/功耗分开，不预宣称全能力验收。
