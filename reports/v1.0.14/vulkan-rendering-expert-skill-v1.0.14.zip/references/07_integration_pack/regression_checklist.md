# Regression Checklist

统一的回归验证清单。任何修改（修复、新增、优化）在宣布完成前，按影响面选择对应类别执行回归。

> 使用方式：先按 `../02_core_mental_model/regression_reasoning.md` 推导影响面，再执行本清单中受影响类别的条目；出口判定按 `../00_expert_entry/verification_gate.md`。

---

## 1. Correctness 回归

- [ ] Validation Layer 无新增错误（debug / release 两个 build 都确认）。
- [ ] 关键 VUID 约束没有违反（对象类型、handle 归属、flag 组合）。
- [ ] API 返回值全部检查，无忽略的错误码。
- [ ] 修改点周边代码路径（if / else 分支、错误路径）都被执行到。
- [ ] 多帧连续运行无 crash、无 device lost、无 validation 报错。

## 2. Rendering 回归

- [ ] RenderDoc 抓帧：draw / dispatch 数量符合预期。
- [ ] 每个 pass 的输入 / 输出内容符合预期（纹理、render target）。
- [ ] descriptor 绑定的资源正确（无空绑定、无旧资源残留）。
- [ ] 画面结果与修改前基线对比：预期变化发生，非预期变化未发生。
- [ ] 边界视角 / 边界参数下无异常（近远裁剪、特殊 clear value、极端相机距离）。

## 3. Resource Lifecycle 回归

- [ ] 新建对象全部有对应销毁路径（无泄漏）。
- [ ] 销毁前相关提交已完成；present semaphore / swapchain 另有 presentation 资源退役证据，不能只等 submit fence / WaitIdle。
- [ ] swapchain recreate 后旧资源（image view / framebuffer / 尺寸相关 image）同步销毁。
- [ ] 销毁函数幂等（重复调用不崩溃、不 double free）。
- [ ] 内存 / 对象计数稳定（长时间运行无持续增长）。

## 4. Synchronization 回归

- [ ] 修改涉及的每个依赖都明确了 producer / consumer / stage / access / layout。
- [ ] fence / semaphore / barrier 的用途没有混用。
- [ ] acquire semaphore 按 frame slot、present wait semaphore 按 swapchain image 复用，或提供等效完成证明；acquire 失败不 reset 未提交的 fence。
- [ ] 跨 queue（compute ↔ graphics）有 semaphore 依赖，并补齐必要的 layout / queue-family ownership release-acquire barrier。
- [ ] 多帧压力下无闪烁、无撕裂、无 GPU hang。

## 5. Android Lifecycle 回归

- [ ] 横竖屏切换（rotation）后画面正确、无 crash。
- [ ] pause → resume 后渲染恢复、无黑屏、无 stale swapchain。
- [ ] Surface destroyed 后 render thread 停止 present，无 use-after-free。
- [ ] Surface recreated 后 swapchain 与尺寸相关资源完整重建。
- [ ] extent 为 0（Surface 未就绪）时正确等待 / 跳帧，无非法创建。
- [ ] logcat 无 surface / swapchain / native window 相关错误。

## 6. Performance 回归

- [ ] 修改目标指标有量化前后对比（frame time / bandwidth / draw call 数）。
- [ ] 没有引入新的瓶颈（CPU 提交耗时、GPU 占用、带宽）。
- [ ] 优化未破坏正确性（画面与基线一致）。
- [ ] 低端设备 / 移动端场景下无退化。

---

## 7. 结果判定

1. 所有受影响类别的条目通过 → 修改完成。
2. 存在无法执行的条目 → 显式列出"未验证项"与原因，不得默认通过。
3. 存在失败条目 → 修改未完成，回到定位 / 修复循环。
4. Validation clean 只是 Correctness 回归的一部分，不能单独作为完成依据。

<a id="hybrid-quality-regression"></a>
## VIS14 回归范围

- [ ] Query-only 禁止误引 SBT/RT shader stage，缺能力走光栅/probe。
- [ ] 正/反 Z、bias、屏外投影者、反射集合、alpha 三类和 OMM 失效。
- [ ] upload/skin→BLAS→TLAS→实际 query stage；scratch 范围、update 条件、compaction 地址/退休。
- [ ] MV 符号/单位/jitter、previous deformation、灯光变化、曝光比值、disocclusion。
- [ ] camera cut、resize/scale、pause、LOD/材质替换、多 View 隔离与 GPU 完成点。
- [ ] visibility/radiance 分离滤波、SR/FG 尺寸和 UI，匹配轨迹 ROI 与持续分档滞回。
- [ ] 旧64与新增20独立检查；原12 token基线、读取隔离、安全打包与200文件上限保留。
- [ ] 原始图像/序列、设备/driver/features、编译器、最终SHA/hash、未运行层明确记录。
