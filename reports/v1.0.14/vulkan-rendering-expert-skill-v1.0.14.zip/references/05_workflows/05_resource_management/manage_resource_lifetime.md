# Workflow: Manage Resource Lifetime

## 0. 适用范围

### 适用

- 需要自定义资源生命周期管理：buffer、image、image view、framebuffer、descriptor pool、pipeline 等。
- 需要处理资源释放与 GPU in-flight 使用的竞争。
- 需要实现 deferred deletion queue、reference counting 或 handle-based 资源系统。
- 需要降低 device lost 风险，确保销毁时资源不再被 GPU 使用。

### 不适用

- 资源生命周期完全由外部引擎（如 UE/Unity/Godot）托管的场景。
- 每帧全量重建所有资源、无需延迟销毁的简单示例程序。
- 纯 headless / compute-only 程序（概念可参考，但 graphics 相关细节需裁剪）。

---

## 1. 任务目标

建立安全的资源生命周期管理：

```text
Resource Handle
→ Ref Count / Ownership
→ In-Flight Tracking (fence / submission ID)
→ Deferred Deletion Queue
→ Safe Destroy (after GPU finished)
→ Device Lost Protection
```

---

## 2. 输入条件

需要确认：

- 平台：Android / Windows / Linux。
- Vulkan 版本。
- Frame-in-flight 数量（2~3）。
- 需要管理的资源类型：buffer、image、view、framebuffer、pipeline、descriptor pool 等。
- 是否使用 handle-based resource system。
- 是否使用 ref counting 或明确 owner。
- 同步机制：fence、semaphore、timeline semaphore、submission ID。
- 是否支持 `VK_EXT_device_fault` 或 device lost 后 dump 机制。

---

## 3. 前置检查

- [ ] Validation Layer 可用。
- [ ] RenderDoc / AGI 可抓帧。
- [ ] Frame-in-flight fence 稳定。
- [ ] 所有 `vkDestroy*` / `vkFree*` 调用可统一收口。
- [ ] 已记录每次 queue submit 对应的 fence 或 submission ID。
- [ ] Android Surface / ANativeWindow 生命周期可追踪。

---

## 4. Vulkan 对象链路

```text
Application Object
→ Resource Handle (weak/strong ref)
→ Vulkan Object (buffer/image/view/pipeline)
→ In-Flight Tracker (fence / timeline value / frame index)
→ Deferred Deletion Queue
→ GPU Complete Signal
→ vkDestroy* / vkFree*
```

---

## 5. 资源设计

| 资源 | 类型 | Usage | 生命周期 | 是否随 swapchain 重建 |
|---|---|---|---|---|
| resource handle | `uint32_t` / struct | 应用层引用资源 | 由 ref count 控制 | 否 |
| resource record | struct | 存储 `VkBuffer`/`VkImage`/`VkImageView` 等 handle 与元数据 | 与 Vulkan 对象同生命周期 | 视资源而定 |
| ref count | `std::atomic<uint32_t>` / counter | 强引用计数 | 归零时进入 deferred queue | 否 |
| deferred deletion entry | struct | 待删除对象 + 完成 fence / submission ID | 直到 GPU 完成 | 否 |
| in-flight tracker | array/ring | 每帧 fence 或 timeline semaphore 值 | per-frame | 否 |

---

## 6. Pipeline / Descriptor 设计

本工作流主要涉及资源生命周期，descriptor / pipeline 复用现有设计：

| Shader set/binding | Vulkan Descriptor | 资源 | Stage |
|---|---|---|---|
| set=0,binding=0 | `UNIFORM_BUFFER` / `UNIFORM_BUFFER_DYNAMIC` | managed per-frame UBO | Vertex / Fragment / Compute |
| set=N,binding=M | `COMBINED_IMAGE_SAMPLER` | managed image view | Fragment / Compute |
| push constant | `VkPushConstantRange` | 生命周期由 command buffer 覆盖 | Vertex / Fragment / Compute |

设计说明：

- descriptor set 引用的 buffer/image 必须保证在 GPU 使用期间有效；ref count 需在 bind 时增加，在 fence 后释放 [SPEC]。
- pipeline layout 和 pipeline 本身通常长生命周期；若动态卸载 material，需确保没有 in-flight command buffer 引用该 pipeline [ENGINE]。

---

## 7. 同步与 Layout 设计

| Producer | Resource | Barrier / Layout | Consumer |
|---|---|---|---|
| resource create | buffer / image | `UNDEFINED` → target layout | first consumer |
| resource use | buffer / image | in-flight tracker 记录 fence | deferred deletion queue |
| fence signaled | resource record | safe to destroy | deletion worker |
| device lost | all in-flight resources | 停止普通提交，协调 CPU 调用，按 lost 路径取证/销毁 | cleanup path |

必须说明：

- 销毁 Vulkan 对象前，必须保证 GPU 不再访问；通常通过 `vkWaitForFences` 或 `vkDeviceWaitIdle` 实现 [SPEC]。
- 使用 timeline semaphore 时，可将每个 submit 关联一个 monotonic submission ID，deferred deletion entry 标记完成 ID，每帧刷新时检查 `vkGetSemaphoreCounterValue` >= entry.id [SPEC]。
- 同一资源被多个 frame 的 command buffer 引用时，必须等所有相关 fence 都 signaled 才能销毁 [ENGINE]。
- Device lost 后，fence 可能永远不会 signaled；vkDeviceWaitIdle 没有 timeout 参数；检查返回值，停止并协调 CPU 调用，按已确认 lost 状态取证并有序清理，不把普通未完成工作当 lost 随意释放 [TOOL]。

---

## 7.5 架构决策（Architecture Decision）

> 进入 §8 实现步骤前先完成本节决策链。决策方法与六要素见 `../../02_core_mental_model/engine_architecture.md` §10。

决策链：

```text
需求 → 约束 → Candidate Architecture → Trade-off → Decision
```

| 阶段 | 本 workflow 的关键决策问题 | 参考 |
|---|---|---|
| 需求 | 建立安全的资源生命周期管理（§1）；架构上先完成两件事：每个被管理资源归入四类生命周期中的哪类；transient 资源是否值得升级为 RenderGraph 托管 [ENGINE] | — |
| 约束 | frames-in-flight 数（§2 的 2~3）、资源类型与总量、平台（移动端显存 budget 小、deferred queue 不宜积压——§9）、团队规模、pass 数量与增长预期 | — |
| Candidate | A：单一全局池 + 本 workflow 的 handle / ref count / deferred deletion 直管全部资源；B：四类分组（Persistent / Per-frame / Transient / Swapchain-dependent）+ 手动 deferred deletion，每类获得针对性策略；C：四类分组 + transient 交给 RenderGraph 托管（first-use → last-use 推导 + aliasing），其余三类仍手动 | D5/D6 |
| Trade-off | A 起步最快，但 frames-in-flight >1 时串帧 hazard 必然出现（D6 不适用条件）；B 需要归类纪律，错分类按类别付出代价（per-frame 错归 → SYNC-HAZARD-WRITE-AFTER-READ；transient 错归 → alias 回收悬空；D6）；C 把 barrier / aliasing 下沉到编译器、显存峰值可推导，但 RG 编译 CPU 开销进入帧预算、声明错误成为新 bug 类别（D5）；移动端 transient 未从 persistent 拆分时显存峰值直接放大（D6）[ANDROID] | D5/D6 |
| Decision | 用 D6 归类判据表逐资源写明归类结论与"为什么不选另一边"。重新评估条件：首次出现 SYNC-HAZARD-WRITE-AFTER-READ → 立即重开 D6 分组决策；手写 barrier >50 处 / 新增 pass 平均改动 >3 个同步点 / transient 显存峰值接近设备 budget → 重开 D5 | — |

决策规则：

- 不默认选择新技术方案；每个 Decision 必须写明"为什么不选另一边"。
- Decision 必须包含重新评估条件（什么信号出现时重开决策）。
- 决策完成后进入 §8；验证仍走 §10 验证方式与 Verification Gate（`../../00_expert_entry/verification_gate.md`）。

---

## 8. 实现步骤

1. **定义 resource handle 与 record**：
   - handle 可以是 32-bit index（generation + index）用于检测 use-after-free [ENGINE]。
   - record 包含 Vulkan object handle、type、ref count、deletion flag、in-flight fence list。
2. **实现 ref counting**：
   - `Acquire(handle)` / `Release(handle)`，原子操作；
   - `Release` 归零后将对象加入 deferred deletion queue [ENGINE]。
3. **实现 in-flight tracking**：
   - 每次 queue submit 记录使用的资源列表与对应 fence；
   - 或记录 submission ID（timeline semaphore）到每个资源 [ENGINE]。
4. **实现 deferred deletion queue**：
   - 每帧或每 N 帧检查队列头部 entry；
   - 若 entry.fence signaled 或 entry.submissionID <= currentGPUID，则调用 `vkDestroy*` / `vkFree*` [ENGINE]。
5. **Frame loop 刷新**：
   - `vkWaitForFences(perFrameFence)` 后，将本 frame 引用的资源标记为可释放；
   - 遍历 deferred queue 执行安全销毁 [SPEC]。
6. **Swapchain recreate 处理**：
   - swapchain image 本身由 swapchain 拥有，应用创建的 image view、framebuffer、depth/offscreen image 仍由应用在相关使用退休后销毁 [SPEC]。
7. **Pipeline / descriptor pool 卸载**：
   - 标记为 pending delete；
   - 等所有引用它的 command buffer 完成后再销毁；
   - 不能在同 frame中销毁刚 bind 的 pipeline [SPEC]。
8. **Device lost 保护**：
   - 捕获 `VK_ERROR_DEVICE_LOST`；
   - 停止提交新命令；
   - vkDeviceWaitIdle 无 timeout 参数；协调 CPU worker 后按已确认 lost 的恢复合同进入 cleanup；
   - 可选使用 `VK_EXT_device_fault` 收集 fault info [TOOL]。
9. **销毁路径**：
   - 先 drain deferred deletion queue（等待所有 fence）；
   - 再按依赖顺序销毁：command buffer → command pool → descriptor pool → pipeline → pipeline layout → image view → image → buffer → device memory [ENGINE]。
10. **调试支持**：
    - 输出当前 alive resource count、deferred queue size、in-flight resource count；
    - 在 validation layer 报 lifetime 错误时，打印资源创建堆栈或 handle [TOOL]。
11. **幂等销毁设计（shutdown safety）**：

    各 destroy/free 命令对可空参数的规则不同，不能统称所有 vkFree* 均允许 NULL；有效父 Device 与具体命令参数仍必须满足。幂等性由 wrapper 状态检查保证 [SPEC][ENGINE]。但 wrapper 仍需主动置空，避免异常路径双重销毁。

    ```text
    SafeDestroy(VkBuffer& buf, VkDevice device, const VkAllocationCallbacks* pAllocator):
        if buf != VK_NULL_HANDLE:
            vkDestroyBuffer(device, buf, pAllocator)
            buf = VK_NULL_HANDLE

    VulkanApp::shutdown():
        if isShutdown: return              // 幂等入口
        isShutdown = true
        if device != VK_NULL_HANDLE: CheckWaitResult(vkDeviceWaitIdle(device)) // 必须有效，处理 lost
        DestroySwapchainDependent()         // view / framebuffer / depth / scene RT
        DrainDeferredDeletionQueue()        // 等待所有 fence 或跳过（device lost）
        DestroyLongLived()                  // pipeline / pipeline_layout / descriptor_pool
        DestroyBase()                       // command_pool / device / instance
        device = VK_NULL_HANDLE
    ```

    关键规则：

    - shutdown wrapper 先检查有效 Device 与状态，再决定等待；不能向空/已销毁 Device 调用 vkDeviceWaitIdle [SPEC]。
    - 每个 `vkDestroy*` 后立即把 handle 置 `VK_NULL_HANDLE`，防止 destructor 与显式 shutdown 双重销毁同一 handle [ENGINE]。
    - AllocationCallbacks 必须与创建时一致，destroy 时传不同 pAllocator 是 undefined behavior [SPEC]。
    - swapchain recreate 与 shutdown 共用清理函数时，必须通过 flag 区分"仅 swapchain-dependent 资源"与"全部资源"，避免 recreate 误销毁长生命周期对象 [ENGINE]。
    - destructor 必须调用 shutdown 并能容忍"对象从未成功创建"场景：所有 handle 为 NULL，wrapper 走 no-op 路径 [ENGINE]。
    - device lost 后 shutdown 不能依赖 fence signal；应跳过 fence 等待直接销毁对象并重建 renderer [TOOL]。
    - `vkDestroyDescriptorSet` 不存在；descriptor set 由 `vkResetDescriptorPool` / `vkDestroyDescriptorPool` 统一回收，幂等设计需作用在 pool 层 [SPEC]。
    - swapchain image / implicit dispatchable handle 由父对象拥有，应用不能直接 destroy，幂等设计需跳过这些对象 [SPEC]。

### 常见多次调用场景

幂等设计的真正价值在于异常路径与组合调用，必须显式覆盖以下场景：

1. **main 显式调用 + 析构调用**：

   ```text
   int main() {
       VulkanApp app;
       app.init();
       app.run();
       app.shutdown();      // 显式调用 1
   }   // 析构再次调用 shutdown —— 必须走 no-op 路径
   ```

   应对：`isShutdown` flag 在 shutdown 入口检查并置位；析构调用时 flag 已 true 直接 return [ENGINE]。

2. **异常路径 + 正常路径**：

   ```text
   VulkanApp::init():
       CreateInstance()           // 成功
       CreateDevice()             // 失败抛异常
       CreateSwapchain()          // 未执行
   } catch (...) {
       shutdown();                // 异常路径调用，部分对象已创建
   }
   ```

   应对：shutdown 必须容忍"对象从未成功创建"场景，所有 handle 为 `VK_NULL_HANDLE`，wrapper 走 no-op 路径 [ENGINE]。

3. **窗口关闭 + 析构**：

   ```text
   OnWindowClose():
       app.shutdown()             // 用户关闭窗口触发
   }   // app 析构再次调用 shutdown
   ```

   应对：同场景 1，`isShutdown` flag 防双重销毁 [ENGINE]。

4. **swapchain recreate + shutdown 共用清理函数**：

   ```text
   OnResize():
       DestroySwapchainDependent()  // 仅销毁 swapchain-dependent 资源
   VulkanApp::shutdown():
       DestroySwapchainDependent()  // 同一函数被复用
       DestroyLongLived()           // 销毁长生命周期资源
       DestroyBase()
   ```

   应对：清理函数本身必须幂等（handle 置空），shutdown 通过 flag 区分"仅 swapchain-dependent"与"全部资源" [ENGINE]。

5. **device lost 后清理 + 正常析构**：

   ```text
   OnDeviceLost():
       emergencyShutdown()          // 跳过 fence 等待，直接销毁
   }   // 析构再次调用 shutdown
   ```

   应对：emergencyShutdown 也必须设置 `isShutdown` flag；device lost 后不能依赖 fence signal，应跳过 fence 等待直接销毁对象 [TOOL]。

通用规则：

- 所有清理函数（包括 DestroySwapchainDependent / DestroyLongLived / DestroyBase）必须**独立幂等**，被重复调用不崩溃 [ENGINE]。
- `isShutdown` flag 是入口幂等保障；handle 置空是函数级幂等保障，两者必须同时存在 [ENGINE]。
- 析构函数应无条件调用 shutdown，确保异常路径下资源也能释放 [ENGINE]。

---

## 9. Android 注意点

- `ANativeWindow` / surface destroy 后，swapchain image 由 `vkDestroySwapchainKHR` 隐式释放；应用不应再保留这些 image 的 view 或 descriptor 引用 [ANDROID]。
- pause / resume 期间应停止 render thread 并等待所有 frame fence，然后 drain deferred deletion queue；resume 后重新创建 surface 相关资源 [ANDROID]。
- rotation / resize 触发的 swapchain recreate 中，尺寸相关 offscreen image 应通过 deferred queue 延迟销毁，确保当前 frame 完成 [ANDROID]。
- 移动端 memory 紧张，deferred queue 不宜积压过多资源；建议每帧刷新并设置最大队列长度 [ANDROID]。
- AGI / logcat 验证：监控 `vkDestroy*` 调用时机、resource alive count、device lost 日志。

---

## 10. 验证方式

- [ ] Validation Layer clean：无 `VUID-vkDestroy*-*-validHandle`、`VUID-vkFree*-*-validHandle`、lifetime hazard 错误 [TOOL]。
- [ ] RenderDoc / AGI：资源在正确帧被销毁，无悬空引用 [TOOL]。
- [ ] 截图 / 数值验证：资源替换/卸载后渲染正确，无白屏/黑屏/旧资源残留。
- [ ] logcat（Android）：无 validation error；可输出 `aliveResources`、`deferredQueueSize`、`inFlightResources`。
- [ ] 性能指标：
  - deferred deletion queue 不持续增长；
  - 无 memory leak（alive resource count 稳定）；
  - `vkWaitForFences` 等待时间合理 [HEUR]。
- [ ] resize / pause / resume / rotation 后资源清理正确。
- [ ] 多帧运行稳定，无 `DEVICE_LOST`；若发生 device lost，保护路径不崩溃。

---

## 11. 常见失败模式

1. **Use-after-free**：handle 引用已销毁资源，未检测 generation [ENGINE]。
2. **提前销毁**：资源仍在 GPU in-flight 使用中就调用 `vkDestroyBuffer` [TOOL]。
3. **Ref count 泄漏**：循环引用或未正确 `Release`，导致资源永不释放 [ENGINE]。
4. **Fence 未记录**：submit 时未将资源与 fence 关联，deferred queue 无法判断安全时机 [ENGINE]。
5. **Device lost 后死等 fence**：device lost 后 fence 不会 signaled，清理路径卡死 [TOOL]。
6. **Swapchain image 误销毁**：应用直接 `vkDestroyImage` swapchain image [SPEC]。
7. **Descriptor pool 提前释放**：pool 被销毁但 command buffer 中仍有 bind 引用 [SPEC]。
8. **Android surface destroy 后继续引用资源**：导致 `VK_ERROR_DEVICE_LOST` [ANDROID]。

---

## 12. 相关 API 卡片

- `../../03_api_manual/03_command_buffer/queue_submit.md`
- `../../03_api_manual/03_command_buffer/fence_semaphore.md`
- `../../03_api_manual/04_buffer_image_memory/buffer.md`
- `../../03_api_manual/04_buffer_image_memory/image.md`
- `../../03_api_manual/02_surface_swapchain/swapchain.md`
- `../../03_api_manual/06_pipeline/pipeline.md`

---

## 13. 相关 Debug Playbook

- `../../04_debug_playbooks/02_crash_hang/device_lost.md`
- `../../04_debug_playbooks/02_crash_hang/gpu_hang.md`
- `../../04_debug_playbooks/03_validation_errors/layout_sync_hazard_errors.md`
- `../../04_debug_playbooks/03_validation_errors/memory_leak.md`
- `../../04_debug_playbooks/05_android_specific/android_surface_lifecycle.md`

---

## 14. 不确定时如何处理

如果信息不足，不直接下结论。优先补充：

- 资源类型与销毁顺序。
- Ref counting 还是明确 owner。
- Frame-in-flight 数量与 fence 机制。
- Deferred deletion queue 刷新策略。
- 发生 device lost 时的调用栈与 fault info。
- Android lifecycle 日志。

<a id="geometry-streaming-retirement"></a>
## 15. Geometry/LOD 驻留、取消与共享退休（C3）

输入：已有 Resource Manager/allocator/提交完成机制；复用 v1.0.12 owner/generation，不新建第二套 manager。GPU-driven 消费前同时验证 residency、地址/索引范围与版本，不以“有 allocation”代替“内容可用”。[ENGINE]

| 数据 | 最小合同 / 发布条件 |
|---|---|
| mesh/LOD record | stable mesh/LOD ID、vertex/index 格式、index type、范围、bounds、误差、generation、resident |
| geometry page/segment | owner Device、allocation 范围、vertex/index offsets，vertexOffset 有符号；普通 buffer 分段即可，不强制 sparse/BDA |
| upload ticket | Engine/Device/resource generation、取消状态、staging 字节、提交 queue/完成点、访问可见性 |
| scene snapshot | mesh/material/地址表及可见命令使用同一有效版本；更新表不能让旧 in-flight 命令读到新旧混合 |

`Requested → Decoding → Reserved → Submitted → Ready → Published → Retiring → Freed` 是引擎建议状态。Ready 必须有上传完成与后续访问依赖；Published 不意味着 staging、旧 buffer 和 metadata 可以立即销毁。[ENGINE][SPEC]

- 未提交取消释放独占 CPU 数据/预约预算；已提交取消只阻止发布，等 copy 完成回收其引用内存。Building/Submitted 的迟到回调再次核对 generation。
- Geometry/texture 上传共享预算：CPU 解码、临时内存、staging in-flight、每帧上传字节、GPU allocation、并存旧版本峰值。软/紧急阈值、滞回和重试退避见 [预算合同](../../03_api_manual/04_buffer_image_memory/vma_usage.md#streaming-budget-policy)。
- LOD 未 resident 时选已就绪粗 LOD/明确替代或跳过，禁止 indirect 指向未上传 buffer。物理迁移后刷新 descriptor/BDA/索引表；地址有效不证明指向正确 generation。
- 移除一个 Engine/Surface 只释放其引用，其他 Engine 的共享 mesh/material 不受影响。引用计数为零还须等待所有 queue/frame 的最后 GPU 使用；一个 queue 的完成值不能代表另一个 queue 已完成。
- 发布新 snapshot 后旧命令、旧地址表、旧 geometry 一起进入原 owner 的退休机制；不能用降低 LOD 或撤销 resident 位掩盖正在使用的旧引用。
- upload→draw 的 buffer barrier 按实际 vertex/index/SSBO 消费者设置，command/count 另有 DRAW_INDIRECT 依赖；跨 queue semaphore 与必要 ownership transfer 分开。

回归：mesh 缺页、预算突降、上传后取消、索引越界/错 signedness、迁移旧地址、Engine A 销毁而 B 继续、反复装卸后待退休列表平台化。Host 模拟不是 Vulkan draw/dispatch 证据。

规范依据：[Vulkan-Docs v1.4.328 resources](https://github.com/KhronosGroup/Vulkan-Docs/blob/d38733398a4bec673bd5d24c904d4739a45f020d/chapters/resources.adoc)、[descriptor 生命周期](https://github.com/KhronosGroup/Vulkan-Docs/blob/d38733398a4bec673bd5d24c904d4739a45f020d/chapters/descriptorsets.adoc)。状态/阈值是 ENGINE 策略，source-read 不代表设备通过。
