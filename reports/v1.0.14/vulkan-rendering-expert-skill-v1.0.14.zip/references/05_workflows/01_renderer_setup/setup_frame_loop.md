# Workflow: Setup Vulkan Frame Loop

## 0. 适用范围

### 适用

- 已完成基础 Vulkan device / swapchain 初始化，需要建立稳定 frame loop。
- 需要支持 frames-in-flight。
- 需要处理 acquire / submit / present。
- 需要为后续 pass 扩展建立稳定骨架。

### 不适用

- 尚未创建 surface / swapchain。
- 只修复某个单独同步错误。
- 只做离屏 compute，无 present。

---

## 1. 任务目标

建立稳定的一帧渲染流程：

```text
Wait Fence
→ Acquire Swapchain Image
→ Reset / Record CommandBuffer（成功后确认会提交）
→ Reset Fence（紧邻 submit）
→ Queue Submit
→ Present
```

---

## 2. 输入条件

需要确认：

- frames-in-flight 数量。
- swapchain image count。
- 每帧 command buffer 分配策略。
- 每帧资源是否独立。
- 是否区分 frame index 和 image index。
- 是否支持 swapchain recreate。

---

## 3. 前置检查

- [ ] swapchain 创建成功。
- [ ] command pool 创建成功。
- [ ] command buffer 可录制。
- [ ] fence / semaphore 创建成功。
- [ ] clear color pass 可运行。
- [ ] API 返回值有日志。

---

## 4. Vulkan 对象链路

```text
FrameResource
→ inFlightFence
→ imageAvailableSemaphore
→ renderFinishedSemaphore
→ CommandBuffer
→ vkAcquireNextImageKHR
→ vkQueueSubmit
→ vkQueuePresentKHR
```

---

## 5. 资源设计

| 资源 | 类型 | Usage | 生命周期 | 是否随 swapchain 重建 |
|---|---|---|---|---|
| imageAvailableSemaphore | `VkSemaphore` | acquire → submit | per-frame | 否 |
| renderFinishedSemaphore | `VkSemaphore` | submit → present | per-swapchain-image | 是，旧数组随旧 present 资源退役 |
| inFlightFence | `VkFence` | CPU 等 GPU | per-frame | 否 |
| command buffer | `VkCommandBuffer` | record frame commands | per-frame 或 per-image | 视策略而定 |

---

## 6. Pipeline / Descriptor 设计

Frame loop 本身不直接设计 pipeline / descriptor。
但必须为后续 pass 预留：

- current frame index
- current swapchain image index
- per-frame descriptor
- per-frame uniform buffer
- command buffer record callback

---

## 7. 同步与 Layout 设计

同步关系：

| Producer | Resource | Barrier / Layout | Consumer |
|---|---|---|---|
| Present Engine | Swapchain Image | imageAvailableSemaphore | Graphics Queue |
| Graphics Queue | Swapchain Image | renderFinishedSemaphore | Present Engine |
| Graphics Queue | Frame Resource | inFlightFence | CPU |

注意：

- Fence 管 CPU-GPU。
- Semaphore 管 GPU-GPU / Queue-Present。
- frame index 不等于 swapchain image index。
- acquire semaphore 按 frame index 管理；renderFinishedSemaphore 按 acquired image index 管理。submit fence 完成不代表 present 已消费 semaphore。
- command buffer 被 GPU 使用期间不能 reset / free。

---

<a id="frame-loop-contract"></a>
## 8. 实现步骤（帧循环权威契约）

1. 创建 per-frame acquire semaphore / fence；按 swapchain image 数量创建 renderFinishedSemaphore。
2. 每帧 wait 当前 frame fence 并检查返回值；仅成功后复用该 frame slot。
3. 调用 `vkAcquireNextImageKHR`。
4. OUT_OF_DATE 标记重建并返回；TIMEOUT / NOT_READY 跳过本轮；SUCCESS / SUBOPTIMAL 继续，后者标记稍后重建。Surface / device lost 走恢复路径。
5. reset command buffer。
6. record command buffer；成功 acquire 后若中途退出，必须处理 image 与待消费的 acquire 信号。
7. 确定会提交后，紧邻 submit reset frame fence。
8. submit command buffer，并等待 imageAvailableSemaphore[frameIndex]；wait stage 覆盖 image 最早访问。
9. signal renderFinishedSemaphore[imageIndex]；检查 submit 返回值，失败则恢复，不进入普通 present / fence wait。
10. present 等待 renderFinishedSemaphore[imageIndex]。
11. 处理 `VK_SUBOPTIMAL_KHR` / `VK_ERROR_OUT_OF_DATE_KHR`。
12. frame index 递增。

### 提前退出与失败分支

| 分支 | 必须保持的状态 |
|---|---|
| wait fence 返回 TIMEOUT 或错误 | 不复用 command buffer / frame resource，不进入 acquire / reset / submit；超时可重试，device lost 进入恢复 |
| acquire 返回 OUT_OF_DATE / TIMEOUT / NOT_READY | 不 reset frame fence，不使用无效 imageIndex；分别重建或跳过 |
| acquire 返回 SUCCESS / SUBOPTIMAL | image 已取得；SUBOPTIMAL 不是“未取得 image”，正常处理本次提交/呈现后安排重建 |
| acquire 成功后录制失败或主动跳过 | 不 reset frame fence；不能直接复用仍有待消费信号的 acquire semaphore 或遗弃 acquired image。进入显式恢复：按规范完成信号消费与 image 处理；不具备恢复协议时停止普通帧循环 |
| reset fence 失败 | 不提交；检查错误并进入恢复，不能假设 fence 状态已更新 |
| submit 失败 | 不 present，不回到普通等待已 reset fence 的路径；单独处理 device lost / 恢复并重建受影响状态，不能假设 fence 将来会 signal |

帧循环摘要、API 卡片和独立段落读取均以本节为准；不是可以忽略调用返回值的可直接复制代码。
非 pending 的 unsignaled fence 也允许 reset；这里把 reset 延迟到 submit 前，是避免失败路径死锁的工程策略，
不是规范要求 fence 必须先 signal。present 资源的退役另见
[Swapchain 重建](../../03_api_manual/02_surface_swapchain/swapchain_recreate.md)，不能用本帧 submit fence 代替。

---

## 9. Android 注意点

- Surface destroyed 后 frame loop 必须暂停。
- acquire / present 返回 out-of-date 时触发 recreate。
- pause 时不要阻塞 UI thread。
- resume 后检查 surface 是否可用。
- extent 为 0 时不要继续渲染。
- logcat 记录 frame loop 状态。

---

## 10. 验证方式

- [ ] clear color 连续稳定显示。
- [ ] 多帧运行无 validation error。
- [ ] resize / rotation 后 frame loop 恢复。
- [ ] frame index / image index 日志正确。
- [ ] RenderDoc / AGI 可连续抓帧。
- [ ] 无 fence wait 死锁。

---

## 11. 常见失败模式

1. fence 在 acquire 前或仍可能跳过 submit 时 reset，导致下一次 wait 死锁。
2. frame index 和 image index 混用。
3. command buffer 仍 in-flight 就 reset。
4. present 没等待 renderFinishedSemaphore。
5. acquire 返回 out-of-date 后继续提交。
6. Android Surface destroyed 后继续 render。

依据：[Swapchain Recreation](https://docs.vulkan.org/tutorial/latest/03_Drawing_a_triangle/04_Swap_chain_recreation.html)、[Swapchain Semaphore Reuse](https://docs.vulkan.org/guide/latest/swapchain_semaphore_reuse.html)。

---

## 12. 相关 API 卡片

- `../../03_api_manual/02_surface_swapchain/swapchain.md`
- `../../03_api_manual/03_command_buffer/queue_submit.md`
- `../../03_api_manual/08_synchronization/fence.md`
- `../../03_api_manual/08_synchronization/semaphore.md`

---

## 13. 相关 Debug Playbook

- `../../04_debug_playbooks/01_visual_issues/black_screen.md`
- `../../04_debug_playbooks/01_visual_issues/flickering.md`
- `../../04_debug_playbooks/02_crash_hang/swapchain_recreate_crash.md`
